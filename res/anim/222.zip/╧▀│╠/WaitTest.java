package com.edu.threadpooltest;

import org.junit.Test;

public class WaitTest {
    @Test
    public void testWait(){
        Object lock = new Object();

        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                synchronized (lock) {
                    System.out.println("Thread1 acquire the lock and start to wait...");
                    try {
                        lock.wait(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Thread1 wake up after 5 seconds and release the lock.");
                }
            }
        });

        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                synchronized (lock) {
                    System.out.println("Thread2 acquire the lock and start to wait...");
                    try {
                        lock.wait(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    System.out.println("Thread2 wake up after 5 seconds and release the lock.");
                }
            }
        });

        thread1.start();
        thread2.start();
    }
}
