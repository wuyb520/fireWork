package com.seer.seersoft.contacts.impl;

public class Test {

    public void sortColor(int[] nums){
        if (nums==null&& nums.length==0){
            return;
        }
        int zero=0;
        int one=0;
        int two=0;
        int j=0;
        for (int i=0;i<nums.length;i++){

            if (nums[i]==0){
                ++zero;
            }else if (nums[i]==1){
                ++one;
            }else if (nums[i]==2){
                ++two;
            }
        }
        while (j<zero){
            nums[j]=0;
            ++j;
        }
        while (j<zero+one){
            nums[j]=1;
            ++j;
        }
        while (j<zero+one+two){
            nums[j]=2;
            ++j;
        }
    }

    public void test(){
        int[] arr=new int[]{2,0,2,1,1,0};
        sortColor(arr);
    }
}
